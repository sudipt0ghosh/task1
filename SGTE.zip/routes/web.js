// "use strict";
// const config = require("../config.json");
// const express = require("express");
// const webRouter = express.Router();
// const authWebRouter = express.Router();

// module.exports = function(app) {
//     app.use("/", webRouter);
//     /*----------------------------------------------------Authorised Routes---------------------------------------------------------*/
//     app.use("/", authWebRouter);
// };